<?php
// Database connection
$conn = mysqli_connect('localhost', 'root', '');

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
echo "Connected to MySQL server successfully<br>";

// Create database
$sql = "CREATE DATABASE IF NOT EXISTS civicsync";
if (mysqli_query($conn, $sql)) {
    echo "Database 'civicsync' created or already exists<br>";
} else {
    die("Error creating database: " . mysqli_error($conn));
}

// Select database
if (!mysqli_select_db($conn, 'civicsync')) {
    die("Error selecting database: " . mysqli_error($conn));
}
echo "Selected database 'civicsync'<br>";

// Drop existing tables to ensure clean setup
$tables = ['user_activity', 'issue_votes', 'issues', 'users'];
foreach ($tables as $table) {
    $sql = "DROP TABLE IF EXISTS $table";
    if (mysqli_query($conn, $sql)) {
        echo "Dropped existing $table table if it existed<br>";
    } else {
        echo "Error dropping $table table: " . mysqli_error($conn) . "<br>";
    }
}

// Create users table
$sql = "CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') DEFAULT 'user',
    status ENUM('active', 'inactive', 'suspended') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login DATETIME DEFAULT NULL,
    UNIQUE INDEX idx_email (email)
)";
if (mysqli_query($conn, $sql)) {
    echo "Users table created successfully<br>";
} else {
    die("Error creating users table: " . mysqli_error($conn));
}

// Create user_activity table
$sql = "CREATE TABLE user_activity (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    action VARCHAR(50) NOT NULL,
    details TEXT,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_activity (user_id, created_at)
)";
if (mysqli_query($conn, $sql)) {
    echo "User activity table created successfully<br>";
} else {
    die("Error creating user activity table: " . mysqli_error($conn));
}

// Create issues table
$sql = "CREATE TABLE issues (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    category ENUM('Infrastructure', 'Safety', 'Environment', 'Other') NOT NULL,
    status ENUM('open', 'in_progress', 'resolved', 'closed') DEFAULT 'open',
    location VARCHAR(255) NOT NULL,
    image_path VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
)";
if (mysqli_query($conn, $sql)) {
    echo "Issues table created successfully<br>";
} else {
    die("Error creating issues table: " . mysqli_error($conn));
}

// Create issue_votes table
$sql = "CREATE TABLE issue_votes (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    issue_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (issue_id) REFERENCES issues(id) ON DELETE CASCADE,
    UNIQUE KEY unique_vote (user_id, issue_id)
)";
if (mysqli_query($conn, $sql)) {
    echo "Issue votes table created successfully<br>";
} else {
    die("Error creating issue votes table: " . mysqli_error($conn));
}

// Verify tables exist
$result = mysqli_query($conn, "SHOW TABLES");
echo "<br>Current tables in database:<br>";
while ($row = mysqli_fetch_row($result)) {
    echo $row[0] . "<br>";
}

echo "<br>Database setup completed!<br>";
echo "<a href='login.php'>Go to Login Page</a>";
?> 