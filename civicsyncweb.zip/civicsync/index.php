<?php
// Initialize the session
session_start();
require_once 'config/database.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CivicSync - Community Issue Management</title>
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js"></script>
</head>
<body>
    <header class="header">
        <div class="container">
            <nav class="navbar">
                <a href="index.php" class="logo">
                    <i class="fas fa-sync-alt"></i> CivicSync
                </a>
                <div class="nav-links">
                    <a href="index.php" class="active">Home</a>
                    <a href="issues_feed.php">Issues</a>
                    <?php if(isLoggedIn()): ?>
                        <a href="report_issue.php">Report Issue</a>
                        <a href="logout.php">Logout</a>
                    <?php else: ?>
                        <a href="login.php">Login</a>
                        <a href="register.php">Register</a>
                    <?php endif; ?>
                </div>
            </nav>
        </div>
    </header>
    <main class="container">
        <section class="hero">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <h1>Welcome to CivicSync</h1>
                        <p class="lead">Your platform for reporting and tracking community issues. Together, we can make our neighborhoods better.</p>
                        <?php if(!isLoggedIn()): ?>
                            <a href="register.php" class="btn btn-primary btn-lg">Get Started</a>
                        <?php else: ?>
                            <a href="report_issue.php" class="btn btn-primary btn-lg">Report an Issue</a>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <img src="assets/images/hero-image.svg" alt="Community Engagement" class="img-fluid">
                    </div>
                </div>
            </div>
        </section>

        <section class="features">
            <div class="container">
                <h2 class="text-center mb-5">How CivicSync Works</h2>
                <div class="row">
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-body text-center">
                                <i class="fas fa-flag fa-3x mb-3 text-primary"></i>
                                <h3 class="card-title">Report Issues</h3>
                                <p class="card-text">Easily report community issues with photos and location details.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-body text-center">
                                <i class="fas fa-vote-yea fa-3x mb-3 text-primary"></i>
                                <h3 class="card-title">Vote on Issues</h3>
                                <p class="card-text">Support issues that matter to you and help prioritize community needs.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-body text-center">
                                <i class="fas fa-chart-line fa-3x mb-3 text-primary"></i>
                                <h3 class="card-title">Track Progress</h3>
                                <p class="card-text">Monitor the status of reported issues and see real-time updates.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="recent-issues">
            <div class="container">
                <h2 class="text-center mb-5">Recent Community Issues</h2>
                <div class="row">
                    <?php
                    // Get recent issues
                    $sql = "SELECT i.*, u.username as reporter_name, 
                           (SELECT COUNT(*) FROM issue_votes WHERE issue_id = i.id) as vote_count
                           FROM issues i 
                           LEFT JOIN users u ON i.user_id = u.id 
                           ORDER BY i.created_at DESC LIMIT 3";
                    $result = $conn->query($sql);
                    
                    if ($result && $result->num_rows > 0):
                        while($issue = $result->fetch_assoc()):
                    ?>
                        <div class="col-md-4">
                            <div class="card issue-card">
                                <?php if ($issue['image_path']): ?>
                                    <img src="<?php echo htmlspecialchars($issue['image_path']); ?>" class="card-img-top" alt="Issue Image">
                                <?php endif; ?>
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo htmlspecialchars($issue['title']); ?></h5>
                                    <div class="issue-meta">
                                        <span class="badge badge-primary"><?php echo htmlspecialchars($issue['category']); ?></span>
                                        <span class="badge badge-<?php echo $issue['status'] === 'open' ? 'success' : 'secondary'; ?>">
                                            <?php echo ucfirst(htmlspecialchars($issue['status'])); ?>
                                        </span>
                                    </div>
                                    <p class="card-text"><?php echo htmlspecialchars($issue['description']); ?></p>
                                    <div class="issue-details">
                                        <p><i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($issue['location']); ?></p>
                                        <p><i class="fas fa-user"></i> Reported by <?php echo htmlspecialchars($issue['reporter_name']); ?></p>
                                        <p><i class="fas fa-calendar"></i> <?php echo date('M d, Y', strtotime($issue['created_at'])); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php 
                        endwhile;
                    else:
                    ?>
                        <div class="col-12 text-center">
                            <p>No issues reported yet.</p>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="text-center mt-4">
                    <a href="issues_feed.php" class="btn btn-primary">View All Issues</a>
                </div>
            </div>
        </section>
    </main>
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3 class="footer-title">About CivicSync</h3>
                    <p>CivicSync is a platform that connects communities with local authorities to address and resolve civic issues efficiently.</p>
                </div>
                <div class="footer-section">
                    <h3 class="footer-title">Quick Links</h3>
                    <ul class="footer-links">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="issues_feed.php">Issues</a></li>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="contact.php">Contact</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3 class="footer-title">Connect With Us</h3>
                    <ul class="footer-links">
                        <li><a href="#"><i class="fab fa-facebook"></i> Facebook</a></li>
                        <li><a href="#"><i class="fab fa-twitter"></i> Twitter</a></li>
                        <li><a href="#"><i class="fab fa-instagram"></i> Instagram</a></li>
                    </ul>
                </div>
            </div>
            <div class="copyright">
                <p>&copy; <?php echo date("Y"); ?> CivicSync. All rights reserved.</p>
            </div>
        </div>
    </footer>
</body>
</html> 