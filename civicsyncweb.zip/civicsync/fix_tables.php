<?php
// Database connection
$conn = mysqli_connect('localhost', 'root', '');

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
echo "Connected to MySQL server successfully<br>";

// Select database
if (!mysqli_select_db($conn, 'civicsync')) {
    die("Error selecting database: " . mysqli_error($conn));
}
echo "Selected database 'civicsync'<br>";

// Check if user_activity table exists
$result = mysqli_query($conn, "SHOW TABLES LIKE 'user_activity'");
if (mysqli_num_rows($result) == 0) {
    echo "Table 'user_activity' does not exist. Creating it...<br>";
    
    // Create user_activity table
    $sql = "CREATE TABLE user_activity (
        id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT NOT NULL,
        action VARCHAR(50) NOT NULL,
        details TEXT,
        ip_address VARCHAR(45),
        user_agent TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        INDEX idx_user_activity (user_id, created_at)
    )";
    
    if (mysqli_query($conn, $sql)) {
        echo "Table 'user_activity' created successfully<br>";
    } else {
        echo "Error creating table: " . mysqli_error($conn) . "<br>";
    }
} else {
    echo "Table 'user_activity' already exists<br>";
}

// Show all tables in database
echo "<br>Current tables in database:<br>";
$result = mysqli_query($conn, "SHOW TABLES");
while ($row = mysqli_fetch_row($result)) {
    echo $row[0] . "<br>";
}

echo "<br>Database check completed!<br>";
echo "<a href='index.php'>Go to Home Page</a>";
?> 