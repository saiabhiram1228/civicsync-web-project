<?php
require_once 'config.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';
require 'phpmailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

session_start();

// Set timezone to match your local time
date_default_timezone_set('Asia/Kolkata'); // Set to Indian Standard Time

if (isset($_POST['submit'])) {
    $email = trim($_POST['email']);
    
    // Check if email exists in database
    $stmt = $conn->prepare("SELECT id, username FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        
        // Generate OTP
        $otp = rand(100000, 999999);
        $otp_expiry = date('Y-m-d H:i:s', strtotime('+15 minutes'));
        
        // Store OTP in database
        $stmt = $conn->prepare("UPDATE users SET reset_otp = ?, reset_otp_expiry = ? WHERE email = ?");
        $stmt->bind_param("sss", $otp, $otp_expiry, $email);
        $stmt->execute();
        
        // Send email with OTP
                $mail = new PHPMailer(true);
        
                try {
            // Server settings
                    $mail->isSMTP();
                    $mail->Host = 'smtp.gmail.com';
                    $mail->SMTPAuth = true;
            $mail->Username = 'saiabhiram241@gmail.com'; // Replace with your email
            $mail->Password = 'klmt dkbm nrol jqag'; // Replace with your app password
                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                    $mail->Port = 587;

            // Recipients
            $mail->setFrom('saiabhiram241@gmail.com', 'Smart Deals');
            $mail->addAddress($email, $user['username']);
            
            // Content
            $mail->isHTML(true);
            $mail->Subject = 'Password Reset OTP';
            $mail->Body = "Hello {$user['username']},<br><br>"
                       . "Your OTP for password reset is: <strong>{$otp}</strong><br>"
                       . "This OTP will expire in 15 minutes.<br><br>"
                       . "If you didn't request this, please ignore this email.<br><br>"
                       . "Best regards,<br>Smart Deals Team";
            
            $mail->send();
            $_SESSION['reset_email'] = $email;
            header("Location: verify.php");
            exit();
            
                } catch (Exception $e) {
            $_SESSION['error'] = "Error sending OTP: " . $mail->ErrorInfo;
        }
    } else {
        $_SESSION['error'] = "Email not found in our records.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - Smart Deals</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .forgot-form {
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            background: white;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            border-radius: 10px;
        }
        .form-floating {
            margin-bottom: 1rem;
        }
        .btn-primary {
            width: 100%;
            padding: 12px;
        }
        .alert {
            border-radius: 8px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container">
        <div class="forgot-form">
            <h2 class="text-center mb-4">Forgot Password</h2>
            
            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger">
                    <?php 
                        echo $_SESSION['error'];
                        unset($_SESSION['error']);
                    ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="form-floating mb-3">
                    <input type="email" class="form-control" id="email" name="email" 
                           placeholder="name@example.com" required>
                    <label for="email">Email address</label>
                </div>
                
                <div class="d-grid gap-2">
                    <button type="submit" name="submit" class="btn btn-primary">
                        <i class="fas fa-paper-plane me-2"></i>Send OTP
                    </button>
                    <a href="login.php" class="btn btn-link text-center">Back to Login</a>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
