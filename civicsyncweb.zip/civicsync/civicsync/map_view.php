<?php
// Initialize the session
session_start();

// Include config file
require_once "config/database.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CivicSync - Map View</title>
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    
    <!-- Leaflet CSS -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js"></script>
    
    <!-- Leaflet JS -->
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
</head>
<body>
    <header class="header">
        <div class="container">
            <nav class="navbar">
                <a href="index.php" class="logo">
                    <i class="fas fa-sync-alt"></i> CivicSync
                </a>
                <div class="nav-links">
                    <a href="index.php">Home</a>
                    <a href="issues_feed.php">Issues</a>
                    <a href="map_view.php" class="active">Map View</a>
                    <?php if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true): ?>
                        <a href="report_issue.php">Report Issue</a>
                        <a href="logout.php">Logout</a>
                    <?php else: ?>
                        <a href="login.php">Login</a>
                        <a href="register.php">Register</a>
                    <?php endif; ?>
                </div>
            </nav>
        </div>
    </header>
    <main class="container-fluid p-0">
        <div class="row no-gutters">
            <!-- Map Container -->
            <div class="col-md-9">
                <div id="map" style="height: 100vh;"></div>
            </div>
            
            <!-- Sidebar -->
            <div class="col-md-3">
                <div class="sidebar p-3">
                    <h3>Filters</h3>
                    <div class="form-group">
                        <label>Category</label>
                        <select class="form-control" id="categoryFilter">
                            <option value="">All Categories</option>
                            <option value="Infrastructure">Infrastructure</option>
                            <option value="Safety">Safety</option>
                            <option value="Environment">Environment</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Status</label>
                        <select class="form-control" id="statusFilter">
                            <option value="">All Statuses</option>
                            <option value="Pending">Pending</option>
                            <option value="In Progress">In Progress</option>
                            <option value="Resolved">Resolved</option>
                            <option value="Closed">Closed</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Sort By</label>
                        <select class="form-control" id="sortFilter">
                            <option value="newest">Newest First</option>
                            <option value="oldest">Oldest First</option>
                            <option value="votes">Most Votes</option>
                        </select>
                    </div>
                    <button class="btn btn-primary btn-block" id="applyFilters">Apply Filters</button>
                </div>
            </div>
        </div>
    </main>
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3 class="footer-title">About CivicSync</h3>
                    <p>CivicSync is a platform that connects communities with local authorities to address and resolve civic issues efficiently.</p>
                </div>
                <div class="footer-section">
                    <h3 class="footer-title">Quick Links</h3>
                    <ul class="footer-links">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="issues_feed.php">Issues</a></li>
                        <li><a href="map_view.php">Map View</a></li>
                        <li><a href="about.php">About Us</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3 class="footer-title">Connect With Us</h3>
                    <ul class="footer-links">
                        <li><a href="#"><i class="fab fa-facebook"></i> Facebook</a></li>
                        <li><a href="#"><i class="fab fa-twitter"></i> Twitter</a></li>
                        <li><a href="#"><i class="fab fa-instagram"></i> Instagram</a></li>
                    </ul>
                </div>
            </div>
            <div class="copyright">
                <p>&copy; <?php echo date("Y"); ?> CivicSync. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script>
        // Initialize map
        var map = L.map('map').setView([0, 0], 2);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);

        // Get user's location
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function(position) {
                map.setView([position.coords.latitude, position.coords.longitude], 13);
            });
        }

        // Function to get marker color based on status
        function getMarkerColor(status) {
            switch(status) {
                case 'Pending': return 'red';
                case 'In Progress': return 'orange';
                case 'Resolved': return 'green';
                case 'Closed': return 'gray';
                default: return 'blue';
            }
        }

        // Function to get marker icon
        function getMarkerIcon(status) {
            return L.divIcon({
                className: 'custom-div-icon',
                html: `<div style="background-color: ${getMarkerColor(status)}; width: 10px; height: 10px; border-radius: 50%; border: 2px solid white;"></div>`,
                iconSize: [14, 14]
            });
        }

        // Load issues from database
        function loadIssues() {
            $.ajax({
                url: 'api/get_issues.php',
                method: 'GET',
                data: {
                    category: $('#categoryFilter').val(),
                    status: $('#statusFilter').val(),
                    sort: $('#sortFilter').val()
                },
                success: function(response) {
                    // Clear existing markers
                    map.eachLayer(function(layer) {
                        if (layer instanceof L.Marker) {
                            map.removeLayer(layer);
                        }
                    });

                    // Add new markers
                    response.forEach(function(issue) {
                        var marker = L.marker([issue.latitude, issue.longitude], {
                            icon: getMarkerIcon(issue.status)
                        }).addTo(map);

                        marker.bindPopup(`
                            <h5>${issue.title}</h5>
                            <p>${issue.description}</p>
                            <p><strong>Status:</strong> ${issue.status}</p>
                            <p><strong>Votes:</strong> ${issue.vote_count}</p>
                            <a href="view_issue.php?id=${issue.id}" class="btn btn-sm btn-primary">View Details</a>
                        `);
                    });
                }
            });
        }

        // Load issues on page load
        loadIssues();

        // Apply filters when button is clicked
        $('#applyFilters').click(function() {
            loadIssues();
        });
    </script>
</body>
</html> 