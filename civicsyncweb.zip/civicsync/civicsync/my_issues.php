<?php
require_once "includes/header.php";
require_once "config/database.php";

// Handle issue deletion
if(isset($_POST["delete"]) && !empty($_POST["delete"])){
    $sql = "DELETE FROM issues WHERE id = ? AND user_id = ?";
    if($stmt = mysqli_prepare($conn, $sql)){
        mysqli_stmt_bind_param($stmt, "ii", $param_id, $param_user_id);
        $param_id = $_POST["delete"];
        $param_user_id = $_SESSION["id"];
        
        if(mysqli_stmt_execute($stmt)){
            header("location: my_issues.php");
        } else{
            echo "Something went wrong. Please try again later.";
        }
        mysqli_stmt_close($stmt);
    }
}

// Handle status update
if(isset($_POST["update_status"]) && !empty($_POST["update_status"])){
    $sql = "UPDATE issues SET status = ? WHERE id = ? AND user_id = ?";
    if($stmt = mysqli_prepare($conn, $sql)){
        mysqli_stmt_bind_param($stmt, "sii", $param_status, $param_id, $param_user_id);
        $param_status = $_POST["new_status"];
        $param_id = $_POST["update_status"];
        $param_user_id = $_SESSION["id"];
        
        if(mysqli_stmt_execute($stmt)){
            header("location: my_issues.php");
        } else{
            echo "Something went wrong. Please try again later.";
        }
        mysqli_stmt_close($stmt);
    }
}

// Fetch user's issues
$sql = "SELECT * FROM issues WHERE user_id = ? ORDER BY created_at DESC";
if($stmt = mysqli_prepare($conn, $sql)){
    mysqli_stmt_bind_param($stmt, "i", $param_user_id);
    $param_user_id = $_SESSION["id"];
    
    if(mysqli_stmt_execute($stmt)){
        $result = mysqli_stmt_get_result($stmt);
    } else{
        echo "Something went wrong. Please try again later.";
    }
    mysqli_stmt_close($stmt);
}
?>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h3>My Reported Issues</h3>
                <a href="report_issue.php" class="btn btn-primary">Report New Issue</a>
            </div>
            <div class="card-body">
                <?php if(mysqli_num_rows($result) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Category</th>
                                    <th>Status</th>
                                    <th>Location</th>
                                    <th>Created At</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($row = mysqli_fetch_assoc($result)): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($row["title"]); ?></td>
                                        <td><?php echo htmlspecialchars($row["category"]); ?></td>
                                        <td>
                                            <?php
                                            $status_class = "";
                                            switch($row["status"]){
                                                case "Pending":
                                                    $status_class = "badge-warning";
                                                    break;
                                                case "In Progress":
                                                    $status_class = "badge-info";
                                                    break;
                                                case "Resolved":
                                                    $status_class = "badge-success";
                                                    break;
                                            }
                                            ?>
                                            <span class="badge <?php echo $status_class; ?>"><?php echo $row["status"]; ?></span>
                                        </td>
                                        <td><?php echo htmlspecialchars($row["location"]); ?></td>
                                        <td><?php echo date("M d, Y H:i", strtotime($row["created_at"])); ?></td>
                                        <td>
                                            <div class="btn-group">
                                                <a href="view_issue.php?id=<?php echo $row["id"]; ?>" class="btn btn-sm btn-info">View</a>
                                                <?php if($row["status"] == "Pending"): ?>
                                                    <a href="edit_issue.php?id=<?php echo $row["id"]; ?>" class="btn btn-sm btn-primary">Edit</a>
                                                    <form method="post" style="display: inline;">
                                                        <input type="hidden" name="delete" value="<?php echo $row["id"]; ?>">
                                                        <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this issue?');">Delete</button>
                                                    </form>
                                                <?php endif; ?>
                                                <div class="btn-group">
                                                    <button type="button" class="btn btn-sm btn-secondary dropdown-toggle" data-toggle="dropdown">
                                                        Update Status
                                                    </button>
                                                    <div class="dropdown-menu">
                                                        <form method="post">
                                                            <input type="hidden" name="update_status" value="<?php echo $row["id"]; ?>">
                                                            <input type="hidden" name="new_status" value="In Progress">
                                                            <button type="submit" class="dropdown-item">Mark as In Progress</button>
                                                        </form>
                                                        <form method="post">
                                                            <input type="hidden" name="update_status" value="<?php echo $row["id"]; ?>">
                                                            <input type="hidden" name="new_status" value="Resolved">
                                                            <button type="submit" class="dropdown-item">Mark as Resolved</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-center">You haven't reported any issues yet. <a href="report_issue.php">Report your first issue</a>.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php require_once "includes/footer.php"; ?> 