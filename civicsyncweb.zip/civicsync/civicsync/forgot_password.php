<?php
session_start();
require_once "config/database.php";

// Check if user is already logged in
if (isLoggedIn()) {
    header("Location: /civicsync/index.php");
    exit();
}

$error = '';
$success = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email_input = isset($_POST['email']) ? $_POST['email'] : '';
    
    if (empty($email_input)) {
        $error = "Please enter your email address.";
    } elseif (!isValidEmail($email_input)) {
        $error = "Please enter a valid email address.";
    } else {
        $email = sanitizeInput($email_input);
        
        // Check if email exists
        $sql = "SELECT id, username FROM users WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            
            // Generate reset token
            $token = generateAuthToken();
            $expiry = date("Y-m-d H:i:s", strtotime("+1 hour"));
            
            // Store token in database
            $update_sql = "UPDATE users SET reset_token = ?, reset_token_expiry = ? WHERE id = ?";
            $update_stmt = $conn->prepare($update_sql);
            $update_stmt->bind_param("ssi", $token, $expiry, $user['id']);
            
            if ($update_stmt->execute()) {
                // Send reset email
                require_once "PHPMailer/PHPMailer.php";
                require_once "PHPMailer/SMTP.php";
                require_once "PHPMailer/Exception.php";
                
                $mail = new PHPMailer\PHPMailer\PHPMailer(true);
                
                try {
                    // Server settings
                    $mail->isSMTP();
                    $mail->Host = 'smtp.gmail.com';
                    $mail->SMTPAuth = true;
                    $mail->Username = 'your-email@gmail.com'; // Replace with your Gmail
                    $mail->Password = 'your-app-password'; // Replace with your Gmail App Password
                    $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
                    $mail->Port = 587;
                    
                    // Recipients
                    $mail->setFrom('your-email@gmail.com', 'CivicSync');
                    $mail->addAddress($email, $user['username']);
                    
                    // Content
                    $mail->isHTML(true);
                    $mail->Subject = 'Password Reset Request';
                    $mail->Body = "
                        <h2>Password Reset Request</h2>
                        <p>Hello {$user['username']},</p>
                        <p>We received a request to reset your password. Click the link below to reset it:</p>
                        <p><a href='http://localhost/civicsync/reset_password.php?token={$token}'>Reset Password</a></p>
                        <p>This link will expire in 1 hour.</p>
                        <p>If you didn't request this, please ignore this email.</p>
                    ";
                    
                    $mail->send();
                    $success = "Password reset link has been sent to your email.";
                    
                    // Log the password reset request
                    logUserActivity($user['id'], 'password_reset_request', 'Password reset requested');
                } catch (Exception $e) {
                    $error = "Failed to send reset email. Please try again later.";
                }
            } else {
                $error = "Something went wrong. Please try again later.";
            }
            
            $update_stmt->close();
        } else {
            $error = "No account found with that email address.";
        }
        
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - CivicSync</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="/civicsync/assets/css/style.css">
</head>
<body>
    <div class="container">
        <div class="row justify-content-center align-items-center min-vh-100">
            <div class="col-md-6 col-lg-5">
                <div class="card shadow">
                    <div class="card-body p-5">
                        <h2 class="text-center mb-4">Forgot Password</h2>
                        <p class="text-center mb-4">Enter your email address to reset your password.</p>
                        
                        <?php if($error): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        
                        <?php if($success): ?>
                            <div class="alert alert-success"><?php echo $success; ?></div>
                        <?php endif; ?>
                        
                        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            
                            <button type="submit" class="btn btn-primary btn-block">Reset Password</button>
                        </form>
                        
                        <div class="text-center mt-4">
                            <p class="mb-0">Remember your password? <a href="/civicsync/login.php">Login</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>