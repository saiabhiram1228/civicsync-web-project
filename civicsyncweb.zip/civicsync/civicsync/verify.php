<?php
require_once 'config.php';
session_start();

// Set timezone to match your local time
date_default_timezone_set('Asia/Kolkata'); // Set to Indian Standard Time

// Redirect if email is not set
if (!isset($_SESSION['reset_email'])) {
    header("Location: forgot.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['otp'])) {
    $entered_otp = trim($_POST['otp']);
    $email = $_SESSION['reset_email'];
    
    // Check if OTP exists and is valid
    $verify_query = "SELECT * FROM users WHERE email = ? AND reset_otp = ? AND reset_otp_expiry > NOW()";
    $stmt = $conn->prepare($verify_query);
    
    if ($stmt === false) {
        die("Error preparing query: " . $conn->error);
    }
    
    $stmt->bind_param("ss", $email, $entered_otp);
        $stmt->execute();
        $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // OTP is valid
        $_SESSION['otp_verified'] = true;
        $_SESSION['reset_email'] = $email;
        
        // Clear the OTP after successful verification
        $clear_otp = "UPDATE users SET reset_otp = NULL, reset_otp_expiry = NULL WHERE email = ?";
        $clear_stmt = $conn->prepare($clear_otp);
            $clear_stmt->bind_param("s", $email);
            $clear_stmt->execute();
        $clear_stmt->close();
        
        header("Location: reset_password.php");
        exit();
    } else {
        $_SESSION['error'] = "Invalid OTP. Please try again.";
    }
    $stmt->close();
}

// Add this at the top of the HTML section
if (isset($_SESSION['debug_stored_otp'])) {
    echo '<div class="alert alert-info">
            Debug Info:<br>
            Stored OTP: ' . $_SESSION['debug_stored_otp'] . '<br>
            Entered OTP: ' . $_SESSION['debug_entered_otp'] . '<br>
            Expiry: ' . $_SESSION['debug_expiry'] . '
          </div>';
    unset($_SESSION['debug_stored_otp']);
    unset($_SESSION['debug_entered_otp']);
    unset($_SESSION['debug_expiry']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify OTP - Smart Deals</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .verify-form {
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            background: white;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            border-radius: 10px;
        }
        .otp-input {
            letter-spacing: 0.5em;
            text-align: center;
            font-size: 1.5em;
        }
        .resend-timer {
            color: #6c757d;
            font-size: 0.9em;
            margin-top: 10px;
        }
        .btn-primary {
            width: 100%;
            padding: 12px;
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container">
        <div class="verify-form">
            <h2 class="text-center mb-4">Verify OTP</h2>
            
            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger">
                    <?php 
                        echo $_SESSION['error'];
                        unset($_SESSION['error']);
                    ?>
                </div>
            <?php endif; ?>
            
            <p class="text-center mb-4">
                We've sent a verification code to<br>
                <strong><?php echo htmlspecialchars($_SESSION['reset_email']); ?></strong>
            </p>
            
            <form method="POST" action="" class="needs-validation" novalidate>
                <div class="mb-3">
                    <label for="otp" class="form-label">Enter OTP</label>
                    <input type="text" class="form-control" id="otp" name="otp" required 
                           pattern="[0-9]{6}" maxlength="6" placeholder="Enter 6-digit OTP">
                    <div class="invalid-feedback">
                        Please enter a valid 6-digit OTP.
                    </div>
                </div>
                
                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary w-100">Verify OTP</button>
                    <div class="text-center resend-timer">
                        Resend OTP in <span id="timer">15:00</span>
                    </div>
                    <a href="forgot.php" class="btn btn-link text-center">Try with different email</a>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Timer functionality
        function startTimer(duration, display) {
            let timer = duration, minutes, seconds;
            let interval = setInterval(function () {
                minutes = parseInt(timer / 60, 10);
                seconds = parseInt(timer % 60, 10);

                minutes = minutes < 10 ? "0" + minutes : minutes;
                seconds = seconds < 10 ? "0" + seconds : seconds;

                display.textContent = minutes + ":" + seconds;

                if (--timer < 0) {
                    clearInterval(interval);
                    display.parentElement.innerHTML = '<a href="forgot.php" class="text-primary">Resend OTP</a>';
                }
            }, 1000);
        }

        window.onload = function () {
            let fifteenMinutes = 60 * 15,
                display = document.querySelector('#timer');
            startTimer(fifteenMinutes, display);
        };

        // OTP input formatting
        document.getElementById('otp').addEventListener('input', function(e) {
            this.value = this.value.replace(/[^0-9]/g, '');
        });
    </script>

    <?php include 'includes/footer.php'; ?>
</body>
</html>