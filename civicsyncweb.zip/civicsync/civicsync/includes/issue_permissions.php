<?php
// Function to check if user can edit an issue
function can_edit_issue($issue_id, $user_id) {
    global $conn;
    
    $sql = "SELECT user_id FROM issues WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $issue_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    if ($row = mysqli_fetch_assoc($result)) {
        // User can edit if they own the issue
        return $row['user_id'] == $user_id;
    }
    
    return false;
}

// Function to check if user can delete an issue
function can_delete_issue($issue_id, $user_id) {
    global $conn;
    
    $sql = "SELECT user_id FROM issues WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $issue_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    if ($row = mysqli_fetch_assoc($result)) {
        // User can delete if they own the issue
        return $row['user_id'] == $user_id;
    }
    
    return false;
}

// Function to check if user has already voted on an issue
function has_voted($issue_id, $user_id) {
    global $conn;
    
    $sql = "SELECT id FROM votes WHERE issue_id = ? AND user_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ii", $issue_id, $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    return mysqli_num_rows($result) > 0;
}

// Function to add a vote to an issue
function add_vote($issue_id, $user_id) {
    global $conn;
    
    // Check if user has already voted
    if (has_voted($issue_id, $user_id)) {
        return false;
    }
    
    // Begin transaction
    mysqli_begin_transaction($conn);
    
    try {
        // Insert vote
        $sql = "INSERT INTO votes (issue_id, user_id) VALUES (?, ?)";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ii", $issue_id, $user_id);
        mysqli_stmt_execute($stmt);
        
        // Log activity
        log_activity($user_id, 'vote', "Voted on issue #$issue_id");
        
        mysqli_commit($conn);
        return true;
    } catch (Exception $e) {
        mysqli_rollback($conn);
        return false;
    }
}

// Function to remove a vote from an issue
function remove_vote($issue_id, $user_id) {
    global $conn;
    
    // Begin transaction
    mysqli_begin_transaction($conn);
    
    try {
        // Delete vote
        $sql = "DELETE FROM votes WHERE issue_id = ? AND user_id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ii", $issue_id, $user_id);
        mysqli_stmt_execute($stmt);
        
        // Log activity
        log_activity($user_id, 'unvote', "Removed vote from issue #$issue_id");
        
        mysqli_commit($conn);
        return true;
    } catch (Exception $e) {
        mysqli_rollback($conn);
        return false;
    }
}
?> 