<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Function to check if user is logged in
function is_logged_in() {
    return isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true;
}

// Function to require login
function require_login() {
    if (!is_logged_in()) {
        header("location: /civicsync/login.php");
        exit;
    }
}

// Function to check if user owns an issue
function user_owns_issue($issue_id) {
    global $conn;
    
    if (!is_logged_in()) {
        return false;
    }
    
    $sql = "SELECT 1 FROM issues WHERE id = ? AND user_id = ?";
    if ($stmt = mysqli_prepare($conn, $sql)) {
        mysqli_stmt_bind_param($stmt, "ii", $issue_id, $_SESSION["id"]);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);
        $owns = mysqli_stmt_num_rows($stmt) > 0;
        mysqli_stmt_close($stmt);
        return $owns;
    }
    return false;
}

// Function to check if issue is editable (Pending status)
function is_issue_editable($issue_id) {
    global $conn;
    
    $sql = "SELECT status FROM issues WHERE id = ?";
    if ($stmt = mysqli_prepare($conn, $sql)) {
        mysqli_stmt_bind_param($stmt, "i", $issue_id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_bind_result($stmt, $status);
        mysqli_stmt_fetch($stmt);
        mysqli_stmt_close($stmt);
        return $status === 'Pending';
    }
    return false;
}

// Function to check if user has already voted on an issue
function has_user_voted($issue_id) {
    global $conn;
    
    if (!is_logged_in()) {
        return false;
    }
    
    $sql = "SELECT 1 FROM votes WHERE issue_id = ? AND user_id = ?";
    if ($stmt = mysqli_prepare($conn, $sql)) {
        mysqli_stmt_bind_param($stmt, "ii", $issue_id, $_SESSION["id"]);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);
        $has_voted = mysqli_stmt_num_rows($stmt) > 0;
        mysqli_stmt_close($stmt);
        return $has_voted;
    }
    return false;
}

// Function to check if user can edit/delete an issue
function can_modify_issue($issue_id) {
    return user_owns_issue($issue_id) && is_issue_editable($issue_id);
}

// Function to generate and store auth token
function generate_auth_token($user_id) {
    global $conn;
    
    $token = bin2hex(random_bytes(32));
    $expiry = date('Y-m-d H:i:s', strtotime('+30 days'));
    
    $sql = "UPDATE users SET auth_token = ?, token_expiry = ? WHERE id = ?";
    if ($stmt = mysqli_prepare($conn, $sql)) {
        mysqli_stmt_bind_param($stmt, "ssi", $token, $expiry, $user_id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        return $token;
    }
    return null;
}

// Function to validate auth token
function validate_auth_token($token) {
    global $conn;
    
    $sql = "SELECT id, name, email FROM users WHERE auth_token = ? AND token_expiry > NOW() AND status = 'active'";
    if ($stmt = mysqli_prepare($conn, $sql)) {
        mysqli_stmt_bind_param($stmt, "s", $token);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        
        if ($row = mysqli_fetch_assoc($result)) {
            $_SESSION["loggedin"] = true;
            $_SESSION["id"] = $row["id"];
            $_SESSION["name"] = $row["name"];
            $_SESSION["email"] = $row["email"];
            return true;
        }
        mysqli_stmt_close($stmt);
    }
    return false;
}

// Function to invalidate auth token
function invalidate_auth_token($user_id) {
    global $conn;
    
    $sql = "UPDATE users SET auth_token = NULL, token_expiry = NULL WHERE id = ?";
    if ($stmt = mysqli_prepare($conn, $sql)) {
        mysqli_stmt_bind_param($stmt, "i", $user_id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        return true;
    }
    return false;
}

// Function to log user activity
function log_activity($user_id, $action, $details = '') {
    global $conn;
    
    $ip = $_SERVER['REMOTE_ADDR'];
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    
    $sql = "INSERT INTO user_activity (user_id, action, details, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)";
    if ($stmt = mysqli_prepare($conn, $sql)) {
        mysqli_stmt_bind_param($stmt, "issss", $user_id, $action, $details, $ip, $user_agent);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    }
} 