<?php
// Initialize the session
session_start();

// Include config file and functions
require_once "config/database.php";
require_once "includes/functions.php";

if (isset($_SESSION['user_id'])) {
    // Log the logout activity
    logUserActivity($_SESSION['user_id'], 'logout', 'User logged out');
    
    // Update last login time
    $update_sql = "UPDATE users SET last_login = NOW() WHERE id = ?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param("i", $_SESSION['user_id']);
    $update_stmt->execute();
    $update_stmt->close();
    
    // Unset all session variables
    $_SESSION = array();
    
    // Destroy the session
    session_destroy();
}

// Redirect to login page
header("Location: login.php");
exit();
?> 