<?php
// Database connection
$conn = mysqli_connect('localhost', 'root', '');

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
echo "Connected to MySQL server successfully<br>";

// Check if database exists
$result = mysqli_query($conn, "SHOW DATABASES LIKE 'civicsync'");
if (mysqli_num_rows($result) == 0) {
    die("Database 'civicsync' does not exist! Please run setup_database.php first.");
}
echo "Database 'civicsync' exists<br>";

// Select database
if (!mysqli_select_db($conn, 'civicsync')) {
    die("Error selecting database: " . mysqli_error($conn));
}
echo "Selected database 'civicsync'<br>";

// Check if tables exist
$tables = ['users', 'user_activity', 'issues', 'issue_votes'];
foreach ($tables as $table) {
    $result = mysqli_query($conn, "SHOW TABLES LIKE '$table'");
    if (mysqli_num_rows($result) == 0) {
        echo "Table '$table' does not exist!<br>";
    } else {
        echo "Table '$table' exists<br>";
    }
}

// Show all tables in database
echo "<br>All tables in database:<br>";
$result = mysqli_query($conn, "SHOW TABLES");
while ($row = mysqli_fetch_row($result)) {
    echo $row[0] . "<br>";
}

echo "<br><a href='setup_database.php'>Run Setup Script</a>";
?> 