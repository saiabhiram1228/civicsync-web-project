<?php
// Initialize the session
session_start();

// Check if the user is logged in, if not then redirect to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}

// Include config file
require_once "config/database.php";

// Define variables and initialize with empty values
$title = $description = $category = $location = "";
$title_err = $description_err = $category_err = $location_err = $image_err = "";

// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
    
    // Validate title
    if(empty($_POST["title"])){
        $title_err = "Please enter a title.";
    } else {
        $title = sanitizeInput($_POST["title"]);
    }
    
    // Validate description
    if(empty($_POST["description"])){
        $description_err = "Please enter a description.";
    } else {
        $description = sanitizeInput($_POST["description"]);
    }
    
    // Validate category
    if(empty($_POST["category"])){
        $category_err = "Please select a category.";
    } else {
        $category = sanitizeInput($_POST["category"]);
    }
    
    // Validate location
    if(empty($_POST["location"])){
        $location_err = "Please enter a location.";
    } else {
        $location = sanitizeInput($_POST["location"]);
    }
    
    // Handle image upload
    $image_path = "";
    if(isset($_FILES["image"]) && $_FILES["image"]["error"] == 0){
        $allowed = array("jpg" => "image/jpg", "jpeg" => "image/jpeg", "gif" => "image/gif", "png" => "image/png");
        $filename = $_FILES["image"]["name"];
        $filetype = $_FILES["image"]["type"];
        $filesize = $_FILES["image"]["size"];
    
        // Verify file extension
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        if(!array_key_exists($ext, $allowed)) {
            $image_err = "Error: Please select a valid file format.";
        }
    
        // Verify file size - 5MB maximum
        $maxsize = 5 * 1024 * 1024;
        if($filesize > $maxsize) {
            $image_err = "Error: File size is larger than the allowed limit.";
        }
    
        if(empty($image_err)){
            // Generate unique filename
            $new_filename = uniqid() . '.' . $ext;
            $upload_path = "uploads/" . $new_filename;
            
            if(move_uploaded_file($_FILES["image"]["tmp_name"], $upload_path)){
                $image_path = $upload_path;
            } else{
                $image_err = "Error uploading file.";
            }
        }
    }
    
    // Check input errors before inserting in database
    if(empty($title_err) && empty($description_err) && empty($category_err) && empty($location_err) && empty($image_err)){
        
        // Prepare an insert statement
        $sql = "INSERT INTO issues (user_id, title, description, category, location, latitude, longitude, image_path) VALUES (?, ?, ?, ?, ?, 0, 0, ?)";
         
        if($stmt = mysqli_prepare($conn, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "isssss", $param_user_id, $param_title, $param_description, $param_category, $param_location, $param_image_path);
            
            // Set parameters
            $param_user_id = $_SESSION["id"];
            $param_title = $title;
            $param_description = $description;
            $param_category = $category;
            $param_location = $location;
            $param_image_path = $image_path;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Log activity
                logUserActivity($_SESSION["id"], 'report_issue', "Reported issue: $title");
                
                // Redirect to issues feed
                header("location: issues_feed.php");
                exit;
            } else {
                echo "Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
    // Close connection
    mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CivicSync - Report Issue</title>
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js"></script>
</head>
<body>
    <header class="header">
        <div class="container">
            <nav class="navbar">
                <a href="index.php" class="logo">
                    <i class="fas fa-sync-alt"></i> CivicSync
                </a>
                <div class="nav-links">
                    <a href="index.php">Home</a>
                    <a href="issues_feed.php">Issues</a>
                    <?php if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true): ?>
                        <a href="report_issue.php">Report Issue</a>
                        <a href="logout.php">Logout</a>
                    <?php else: ?>
                        <a href="login.php">Login</a>
                        <a href="register.php">Register</a>
                    <?php endif; ?>
                </div>
            </nav>
        </div>
    </header>
    <main class="container">
        <div class="form-container">
            <h2>Report an Issue</h2>
            <p>Please fill this form to report a community issue.</p>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label>Title</label>
                    <input type="text" name="title" class="form-control <?php echo (!empty($title_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $title; ?>">
                    <span class="invalid-feedback"><?php echo $title_err; ?></span>
                </div>    
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" class="form-control <?php echo (!empty($description_err)) ? 'is-invalid' : ''; ?>" rows="5"><?php echo $description; ?></textarea>
                    <span class="invalid-feedback"><?php echo $description_err; ?></span>
                </div>
                <div class="form-group">
                    <label>Category</label>
                    <select name="category" class="form-control <?php echo (!empty($category_err)) ? 'is-invalid' : ''; ?>">
                        <option value="">Select a category</option>
                        <option value="Infrastructure">Infrastructure</option>
                        <option value="Safety">Safety</option>
                        <option value="Environment">Environment</option>
                        <option value="Other">Other</option>
                    </select>
                    <span class="invalid-feedback"><?php echo $category_err; ?></span>
                </div>
                <div class="form-group">
                    <label>Location</label>
                    <input type="text" name="location" class="form-control <?php echo (!empty($location_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $location; ?>">
                    <span class="invalid-feedback"><?php echo $location_err; ?></span>
                </div>
                <div class="form-group">
                    <label>Image (Optional)</label>
                    <input type="file" name="image" class="form-control-file <?php echo (!empty($image_err)) ? 'is-invalid' : ''; ?>">
                    <span class="invalid-feedback"><?php echo $image_err; ?></span>
                    <small class="form-text text-muted">Max file size: 5MB. Allowed formats: JPG, JPEG, PNG, GIF</small>
                </div>
                <div class="form-group">
                    <input type="submit" class="btn btn-primary" value="Submit">
                    <input type="reset" class="btn btn-secondary ml-2" value="Reset">
                </div>
            </form>
        </div>
    </main>
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3 class="footer-title">About CivicSync</h3>
                    <p>CivicSync is a platform that connects communities with local authorities to address and resolve civic issues efficiently.</p>
                </div>
                <div class="footer-section">
                    <h3 class="footer-title">Quick Links</h3>
                    <ul class="footer-links">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="issues_feed.php">Issues</a></li>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="contact.php">Contact</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3 class="footer-title">Connect With Us</h3>
                    <ul class="footer-links">
                        <li><a href="#"><i class="fab fa-facebook"></i> Facebook</a></li>
                        <li><a href="#"><i class="fab fa-twitter"></i> Twitter</a></li>
                        <li><a href="#"><i class="fab fa-instagram"></i> Instagram</a></li>
                    </ul>
                </div>
            </div>
            <div class="copyright">
                <p>&copy; <?php echo date("Y"); ?> CivicSync. All rights reserved.</p>
            </div>
        </div>
    </footer>
</body>
</html> 