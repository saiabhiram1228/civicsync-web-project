<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include necessary files
require_once __DIR__ . "/../config/database.php";
require_once __DIR__ . "/auth.php";

// Check for auth token if user is not logged in
if (!isset($_SESSION["loggedin"]) && isset($_COOKIE['auth_token'])) {
    validate_auth_token($_COOKIE['auth_token']);
}

// Function to sanitize input
function sanitize_input($data) {
    global $conn;
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return mysqli_real_escape_string($conn, $data);
}

// Function to validate CSRF token
function validate_csrf_token() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
            http_response_code(403);
            die('Invalid CSRF token');
        }
    }
    
    return $_SESSION['csrf_token'];
}

// Get CSRF token for forms
$csrf_token = validate_csrf_token(); 