<?php
// Initialize the session
session_start();

// Include config file
require_once "config/database.php";
require_once "includes/issue_permissions.php";

// Check if user is logged in
if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

// Get all issues with user info and vote status
$query = "SELECT i.*, u.username as reporter_name, 
          (SELECT COUNT(*) FROM issue_votes WHERE issue_id = i.id) as vote_count,
          (SELECT COUNT(*) FROM issue_votes WHERE issue_id = i.id AND user_id = ?) as user_vote
          FROM issues i 
          LEFT JOIN users u ON i.user_id = u.id 
          ORDER BY i.created_at DESC";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();
$issues = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CivicSync - Issues Feed</title>
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js"></script>
</head>
<body>
    <header class="header">
        <div class="container">
            <nav class="navbar">
                <a href="index.php" class="logo">
                    <i class="fas fa-sync-alt"></i> CivicSync
                </a>
                <div class="nav-links">
                    <a href="index.php">Home</a>
                    <a href="issues_feed.php" class="active">Issues</a>
                    <a href="report_issue.php">Report Issue</a>
                    <a href="logout.php">Logout</a>
                </div>
            </nav>
        </div>
    </header>
    <main class="container">
        <div class="issues-container">
            <h2>Community Issues</h2>
            <div class="row">
                <?php foreach ($issues as $issue): ?>
                    <div class="col-md-6 col-lg-4 mb-4">
                        <div class="card issue-card">
                            <?php if ($issue['image_path']): ?>
                                <img src="<?php echo htmlspecialchars($issue['image_path']); ?>" class="card-img-top" alt="Issue Image">
                            <?php endif; ?>
                            <div class="card-body">
                                <h5 class="card-title"><?php echo htmlspecialchars($issue['title']); ?></h5>
                                <div class="issue-meta">
                                    <span class="badge badge-primary"><?php echo htmlspecialchars($issue['category']); ?></span>
                                    <span class="badge badge-<?php echo $issue['status'] === 'open' ? 'success' : 'secondary'; ?>">
                                        <?php echo ucfirst(htmlspecialchars($issue['status'])); ?>
                                    </span>
                                </div>
                                <p class="card-text"><?php echo htmlspecialchars($issue['description']); ?></p>
                                <div class="issue-details">
                                    <p><i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($issue['location']); ?></p>
                                    <p><i class="fas fa-user"></i> Reported by <?php echo htmlspecialchars($issue['reporter_name']); ?></p>
                                    <p><i class="fas fa-calendar"></i> <?php echo date('M d, Y', strtotime($issue['created_at'])); ?></p>
                                </div>
                                <div class="issue-actions">
                                    <button class="btn btn-outline-primary vote-btn" 
                                            data-issue-id="<?php echo $issue['id']; ?>"
                                            data-voted="<?php echo $issue['user_vote'] > 0 ? 'true' : 'false'; ?>">
                                        <i class="fas fa-thumbs-up"></i>
                                        <span class="vote-count"><?php echo $issue['vote_count']; ?></span>
                                    </button>
                                    
                                    <?php if ($issue['user_id'] == $_SESSION['user_id']): ?>
                                        <button class="btn btn-primary edit-issue" 
                                                data-issue-id="<?php echo $issue['id']; ?>"
                                                data-toggle="modal" 
                                                data-target="#editIssueModal">
                                            <i class="fas fa-edit"></i> Edit
                                        </button>
                                        <button class="btn btn-danger delete-issue" 
                                                data-issue-id="<?php echo $issue['id']; ?>">
                                            <i class="fas fa-trash"></i> Delete
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </main>

    <!-- Edit Issue Modal -->
    <div class="modal fade" id="editIssueModal" tabindex="-1" role="dialog" aria-labelledby="editIssueModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editIssueModalLabel">Edit Issue</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="editIssueForm">
                        <input type="hidden" id="editIssueId" name="issue_id">
                        <div class="form-group">
                            <label for="editTitle">Title</label>
                            <input type="text" class="form-control" id="editTitle" name="title" required>
                        </div>
                        <div class="form-group">
                            <label for="editDescription">Description</label>
                            <textarea class="form-control" id="editDescription" name="description" rows="3" required></textarea>
                        </div>
                        <div class="form-group">
                            <label for="editCategory">Category</label>
                            <select class="form-control" id="editCategory" name="category" required>
                                <option value="infrastructure">Infrastructure</option>
                                <option value="safety">Safety</option>
                                <option value="environment">Environment</option>
                                <option value="other">Other</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="editLocation">Location</label>
                            <input type="text" class="form-control" id="editLocation" name="location" required>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="saveIssueChanges">Save Changes</button>
                </div>
            </div>
        </div>
    </div>

    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3 class="footer-title">About CivicSync</h3>
                    <p>CivicSync is a platform that connects communities with local authorities to address and resolve civic issues efficiently.</p>
                </div>
                <div class="footer-section">
                    <h3 class="footer-title">Quick Links</h3>
                    <ul class="footer-links">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="issues_feed.php">Issues</a></li>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="contact.php">Contact</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3 class="footer-title">Connect With Us</h3>
                    <ul class="footer-links">
                        <li><a href="#"><i class="fab fa-facebook"></i> Facebook</a></li>
                        <li><a href="#"><i class="fab fa-twitter"></i> Twitter</a></li>
                        <li><a href="#"><i class="fab fa-instagram"></i> Instagram</a></li>
                    </ul>
                </div>
            </div>
            <div class="copyright">
                <p>&copy; <?php echo date("Y"); ?> CivicSync. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script>
    $(document).ready(function() {
        // Handle voting
        $('.vote-btn').click(function() {
            const btn = $(this);
            const issueId = btn.data('issue-id');
            const hasVoted = btn.data('voted') === 'true';
            
            $.ajax({
                url: 'api/vote.php',
                method: 'POST',
                data: {
                    issue_id: issueId,
                    action: hasVoted ? 'unvote' : 'vote'
                },
                success: function(response) {
                    if (response.success) {
                        const voteCount = btn.find('.vote-count');
                        const currentCount = parseInt(voteCount.text());
                        voteCount.text(hasVoted ? currentCount - 1 : currentCount + 1);
                        btn.data('voted', !hasVoted);
                    }
                }
            });
        });

        // Handle issue deletion
        $('.delete-issue').click(function() {
            if (confirm('Are you sure you want to delete this issue?')) {
                const issueId = $(this).data('issue-id');
                
                $.ajax({
                    url: 'api/manage_issue.php',
                    method: 'POST',
                    data: {
                        action: 'delete',
                        issue_id: issueId
                    },
                    success: function(response) {
                        if (response.success) {
                            location.reload();
                        }
                    }
                });
            }
        });

        // Handle issue editing
        $('.edit-issue').click(function() {
            const issueId = $(this).data('issue-id');
            const card = $(this).closest('.card');
            
            $('#editIssueId').val(issueId);
            $('#editTitle').val(card.find('.card-title').text());
            $('#editDescription').val(card.find('.card-text').text());
            $('#editCategory').val(card.find('.badge-primary').text());
            $('#editLocation').val(card.find('.fa-map-marker-alt').parent().text().trim());
        });

        // Save issue changes
        $('#saveIssueChanges').click(function() {
            const formData = $('#editIssueForm').serialize();
            
            $.ajax({
                url: 'api/manage_issue.php',
                method: 'POST',
                data: formData + '&action=edit',
                success: function(response) {
                    if (response.success) {
                        location.reload();
                    }
                }
            });
        });
    });
    </script>
</body>
</html> 