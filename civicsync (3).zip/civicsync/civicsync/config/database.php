<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

/* Database credentials */
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'civicsync');

/* Attempt to connect to MySQL database */
$conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// Check connection
if($conn === false){
    die("ERROR: Could not connect to database. " . mysqli_connect_error());
}

// Set charset to ensure proper handling of special characters
mysqli_set_charset($conn, "utf8mb4");

// Set timezone
date_default_timezone_set('UTC');

// Function to log user activity
function logUserActivity($user_id, $action, $details = '') {
    global $conn;
    
    if($user_id > 0) {
        $ip_address = $_SERVER['REMOTE_ADDR'];
        $sql = "INSERT INTO user_activity_log (user_id, activity_type, description, ip_address) VALUES (?, ?, ?, ?)";
        if($stmt = mysqli_prepare($conn, $sql)){
            mysqli_stmt_bind_param($stmt, "isss", $user_id, $action, $details, $ip_address);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
        }
    }
}

// Function to get user role
function getUserRole() {
    return isset($_SESSION['role']) ? $_SESSION['role'] : 'guest';
}

// Function to check if user is admin
function isAdmin() {
    return getUserRole() === 'admin';
}

// Function to generate authentication token
function generateAuthToken() {
    return bin2hex(random_bytes(32));
}

// Function to validate email
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

// Function to redirect with message
function redirectWithMessage($url, $message, $type = 'info') {
    $_SESSION['message'] = $message;
    $_SESSION['message_type'] = $type;
    header("Location: $url");
    exit();
}

// Function to display flash message
function displayFlashMessage() {
    if (isset($_SESSION['message'])) {
        $message = $_SESSION['message'];
        $type = isset($_SESSION['message_type']) ? $_SESSION['message_type'] : 'info';
        unset($_SESSION['message'], $_SESSION['message_type']);
        return "<div class='alert alert-$type'>$message</div>";
    }
    return '';
}

// Function to check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

// Function to require login
function requireLogin() {
    if (!isLoggedIn()) {
        header("location: /civicsync/login.php");
        exit();
    }
}

// Function to sanitize user input
function sanitizeInput($data) {
    global $conn;
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return mysqli_real_escape_string($conn, $data);
}

// Function to format date
function formatDate($date) {
    return date('M d, Y', strtotime($date));
}

// Function to get time ago
function timeAgo($datetime) {
    $time = strtotime($datetime);
    $now = time();
    $diff = $now - $time;
    
    if ($diff < 60) {
        return "just now";
    } elseif ($diff < 3600) {
        $mins = floor($diff / 60);
        return $mins . " minute" . ($mins > 1 ? "s" : "") . " ago";
    } elseif ($diff < 86400) {
        $hours = floor($diff / 3600);
        return $hours . " hour" . ($hours > 1 ? "s" : "") . " ago";
    } else {
        return formatDate($datetime);
    }
}

// Function to truncate text
function truncateText($text, $length = 100) {
    if (strlen($text) <= $length) {
        return $text;
    }
    return substr($text, 0, $length) . "...";
}

// Function to get status badge class
function getStatusBadgeClass($status) {
    switch ($status) {
        case 'open':
            return 'badge-success';
        case 'in_progress':
            return 'badge-warning';
        case 'resolved':
            return 'badge-info';
        case 'closed':
            return 'badge-secondary';
        default:
            return 'badge-primary';
    }
}

// Function to get category icon
function getCategoryIcon($category) {
    switch ($category) {
        case 'infrastructure':
            return 'fa-road';
        case 'environment':
            return 'fa-tree';
        case 'safety':
            return 'fa-shield-alt';
        case 'education':
            return 'fa-graduation-cap';
        case 'health':
            return 'fa-heartbeat';
        case 'other':
            return 'fa-ellipsis-h';
        default:
            return 'fa-question-circle';
    }
}

// Function to get current page
function getCurrentPage() {
    return $_SERVER['PHP_SELF'];
}
?> 