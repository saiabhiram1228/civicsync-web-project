<?php
session_start();
require_once "../config/database.php";
require_once "../includes/issue_permissions.php";

// Set response header to JSON
header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    http_response_code(401);
    echo json_encode(["error" => "You must be logged in to vote"]);
    exit;
}

// Check if it's a POST request
if ($_SERVER["REQUEST_METHOD"] != "POST") {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
    exit;
}

// Get and validate issue_id
$issue_id = isset($_POST["issue_id"]) ? intval($_POST["issue_id"]) : 0;
if ($issue_id <= 0) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid issue ID"]);
    exit;
}

// Get action (vote or unvote)
$action = isset($_POST["action"]) ? $_POST["action"] : "";
if (!in_array($action, ["vote", "unvote"])) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid action"]);
    exit;
}

try {
    if ($action === "vote") {
        if (has_voted($issue_id, $_SESSION["id"])) {
            http_response_code(400);
            echo json_encode(["error" => "You have already voted on this issue"]);
            exit;
        }
        
        if (add_vote($issue_id, $_SESSION["id"])) {
            echo json_encode(["success" => true, "message" => "Vote added successfully"]);
        } else {
            http_response_code(500);
            echo json_encode(["error" => "Failed to add vote"]);
        }
    } else {
        if (!has_voted($issue_id, $_SESSION["id"])) {
            http_response_code(400);
            echo json_encode(["error" => "You haven't voted on this issue"]);
            exit;
        }
        
        if (remove_vote($issue_id, $_SESSION["id"])) {
            echo json_encode(["success" => true, "message" => "Vote removed successfully"]);
        } else {
            http_response_code(500);
            echo json_encode(["error" => "Failed to remove vote"]);
        }
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(["error" => "An error occurred while processing your request"]);
}
?> 