<?php
// Initialize the session
session_start();

// Include config file
require_once "../config/database.php";

// Set headers for JSON response
header('Content-Type: application/json');

// Get filter parameters
$category = isset($_GET['category']) ? $_GET['category'] : '';
$status = isset($_GET['status']) ? $_GET['status'] : '';
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'newest';

// Build the query
$sql = "SELECT i.*, u.username as reporter_name, 
        (SELECT COUNT(*) FROM votes v WHERE v.issue_id = i.id) as vote_count
        FROM issues i 
        LEFT JOIN users u ON i.user_id = u.id 
        WHERE 1=1";

$params = array();

// Add category filter if specified
if (!empty($category)) {
    $sql .= " AND i.category = ?";
    $params[] = $category;
}

// Add status filter if specified
if (!empty($status)) {
    $sql .= " AND i.status = ?";
    $params[] = $status;
}

// Add sorting
switch ($sort) {
    case 'oldest':
        $sql .= " ORDER BY i.created_at ASC";
        break;
    case 'votes':
        $sql .= " ORDER BY vote_count DESC";
        break;
    case 'newest':
    default:
        $sql .= " ORDER BY i.created_at DESC";
        break;
}

try {
    // Prepare and execute the query
    $stmt = $conn->prepare($sql);
    if (!empty($params)) {
        $types = str_repeat('s', count($params));
        $stmt->bind_param($types, $params[0], isset($params[1]) ? $params[1] : null);
    }
    $stmt->execute();
    $result = $stmt->get_result();

    // Fetch all issues
    $issues = array();
    while ($row = $result->fetch_assoc()) {
        // Format the data
        $issue = array(
            'id' => $row['id'],
            'title' => $row['title'],
            'description' => $row['description'],
            'category' => $row['category'],
            'status' => $row['status'],
            'latitude' => $row['latitude'],
            'longitude' => $row['longitude'],
            'created_at' => $row['created_at'],
            'reporter_name' => $row['reporter_name'],
            'vote_count' => $row['vote_count']
        );
        $issues[] = $issue;
    }

    // Return the issues as JSON
    echo json_encode($issues);

} catch (Exception $e) {
    // Return error response
    http_response_code(500);
    echo json_encode(array('error' => 'Failed to fetch issues: ' . $e->getMessage()));
}

// Close the connection
$stmt->close();
$conn->close();
?> 