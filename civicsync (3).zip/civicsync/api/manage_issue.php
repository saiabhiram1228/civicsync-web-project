<?php
session_start();
require_once "../config/database.php";
require_once "../includes/issue_permissions.php";

// Set response header to JSON
header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    http_response_code(401);
    echo json_encode(["error" => "You must be logged in to perform this action"]);
    exit;
}

// Check if it's a POST request
if ($_SERVER["REQUEST_METHOD"] != "POST") {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
    exit;
}

// Get and validate issue_id
$issue_id = isset($_POST["issue_id"]) ? intval($_POST["issue_id"]) : 0;
if ($issue_id <= 0) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid issue ID"]);
    exit;
}

// Get action (edit or delete)
$action = isset($_POST["action"]) ? $_POST["action"] : "";
if (!in_array($action, ["edit", "delete"])) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid action"]);
    exit;
}

try {
    if ($action === "edit") {
        // Check if user can edit this issue
        if (!can_edit_issue($issue_id, $_SESSION["id"])) {
            http_response_code(403);
            echo json_encode(["error" => "You don't have permission to edit this issue"]);
            exit;
        }
        
        // Validate required fields
        $required_fields = ["title", "description", "category", "location"];
        foreach ($required_fields as $field) {
            if (!isset($_POST[$field]) || empty(trim($_POST[$field]))) {
                http_response_code(400);
                echo json_encode(["error" => "Missing required field: $field"]);
                exit;
            }
        }
        
        // Sanitize input
        $title = sanitize_input($_POST["title"]);
        $description = sanitize_input($_POST["description"]);
        $category = sanitize_input($_POST["category"]);
        $location = sanitize_input($_POST["location"]);
        
        // Update issue
        $sql = "UPDATE issues SET title = ?, description = ?, category = ?, location_description = ? WHERE id = ? AND user_id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ssssii", $title, $description, $category, $location, $issue_id, $_SESSION["id"]);
        
        if (mysqli_stmt_execute($stmt)) {
            // Log activity
            log_activity($_SESSION["id"], 'edit_issue', "Edited issue #$issue_id");
            echo json_encode(["success" => true, "message" => "Issue updated successfully"]);
        } else {
            http_response_code(500);
            echo json_encode(["error" => "Failed to update issue"]);
        }
    } else {
        // Check if user can delete this issue
        if (!can_delete_issue($issue_id, $_SESSION["id"])) {
            http_response_code(403);
            echo json_encode(["error" => "You don't have permission to delete this issue"]);
            exit;
        }
        
        // Delete issue
        $sql = "DELETE FROM issues WHERE id = ? AND user_id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ii", $issue_id, $_SESSION["id"]);
        
        if (mysqli_stmt_execute($stmt)) {
            // Log activity
            log_activity($_SESSION["id"], 'delete_issue', "Deleted issue #$issue_id");
            echo json_encode(["success" => true, "message" => "Issue deleted successfully"]);
        } else {
            http_response_code(500);
            echo json_encode(["error" => "Failed to delete issue"]);
        }
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(["error" => "An error occurred while processing your request"]);
}
?> 